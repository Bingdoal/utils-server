INSERT INTO t_pocket_system_bank (bank_id,is_active, display_name, icon_url, priority, support_action) VALUES
(2500001,1,'Standard Bank','https://s.sporty.net/common/main/res/Standard-13c1d1d6-2680-4310-b5b3-2f34614b1e56.png',0, 2),
(2500002,1,'FNB','https://s.sporty.net/common/main/res/FNB-163b39b9-eaee-4e65-98ee-94632c04e38a.png',1, 2),
(2500003,1,'Nedbank','https://s.sporty.net/common/main/res/Nedbank-72488640-10a7-4610-bb97-924d58356a2d.png',0, 2),
(2500006,1,'RMB','https://s.sporty.net/common/main/res/RMB-02e9bdd3-b922-49db-8015-e40498682890.png',0, 2),
(2500007,1,'CitiBank','https://s.sporty.net/common/main/res/Citibank-d4264d8d-8e21-4b95-8e99-7fb69a8d6fbf.png',0, 2),
(2500009,1,'Access Bank','https://s.sporty.net/common/main/res/Access-17f46cf6-d039-463b-8a9b-d4d1c5ac8044.png',0, 2),
(2500010,1,'African Bank','https://s.sporty.net/common/main/res/African-971a6315-bbd8-4d94-b7d1-d67b3237bbe8.png',0, 2),
(2500011,1,'Ubank Limited','https://s.sporty.net/common/main/res/Ubank-430e3a00-7413-411a-aaf4-df872213d83a.png',0, 2),
(2500012,1,'Mercantile Bank','https://s.sporty.net/common/main/res/Mercantile-060421be-d8a7-48f0-bd2a-6b4076890cc7.png',0, 2),
(2500013,1,'Bidvest Bank','https://s.sporty.net/common/main/res/Bidvest-e8adad49-09f6-4368-bf89-b3069c60a609.png',0, 2),
(2500014,1,'Capitec','https://s.sporty.net/common/main/res/Capitec-f4657625-fbbc-4205-8468-a39e3f701e00.png',0, 2),
(2500015,1,'Investec','https://s.sporty.net/common/main/res/Investec-e892d34c-15bc-404b-b01d-360407026b84.png',0, 2),
(2500016,1,'HSBC Bank','https://s.sporty.net/common/main/res/HSBC-06361a26-7eed-40e9-a222-e946a8528764.png',0, 2),
(2500017,1,'ABSA','https://s.sporty.net/common/main/res/ABSA-d475042c-6838-4b4c-aeef-6091ef98dd37.png',0, 2),
(2500018,1,'TymeBank','https://s.sporty.net/common/main/res/TymeBank-ea6a64b5-f6f6-4418-84ef-0a3e585d476c.png',0, 2),
(2500019,1,'Discovery Bank','https://s.sporty.net/common/main/res/Discovery-23a61768-edae-4e90-8154-bb166c5da004.png',0, 2),
(2500020,1,'Sasfin','https://s.sporty.net/common/main/res/Sasfin-856aa63d-a44c-43f7-9d88-576669ce604f.png',0, 2),
(2500021,1,'Bank Of China','https://s.sporty.net/common/main/res/Bank-of-China-a42a2a78-4b88-4eea-92ed-fe1547710be9.png',0, 2),
(2500022,1,'Standard Chartered Bank','https://s.sporty.net/common/main/res/Standard-Chartered-756bdf1c-b160-4332-a979-e8f433ffa624.png',0, 2),
(2500023,1,'Permanent Bank','https://s.sporty.net/common/main/res/Permanent-f4503031-889e-4cdf-9288-ba86b09ef747.png',0, 2);

UPDATE t_pocket_bank_support SET bank_id =2500001 WHERE bank_code = '051001-Standard Bank';
UPDATE t_pocket_bank_support SET bank_id =2500002 WHERE bank_code = '1-FNB';
UPDATE t_pocket_bank_support SET bank_id =2500003 WHERE bank_code = '198765-Nedbank';
UPDATE t_pocket_bank_support SET bank_id =2500001 WHERE bank_code = '2-Standard Bank Instant Money';
UPDATE t_pocket_bank_support SET bank_id =2500002 WHERE bank_code = '250655-FNB';
UPDATE t_pocket_bank_support SET bank_id =2500006 WHERE bank_code = '250655-RMB';
UPDATE t_pocket_bank_support SET bank_id =2500007 WHERE bank_code = '350005-CitiBank';
UPDATE t_pocket_bank_support SET bank_id =2500003 WHERE bank_code = '4-Nedbank Cardless';
UPDATE t_pocket_bank_support SET bank_id =2500009 WHERE bank_code = '410105-Access Bank';
UPDATE t_pocket_bank_support SET bank_id =2500010 WHERE bank_code = '430000-African Bank';
UPDATE t_pocket_bank_support SET bank_id =2500011 WHERE bank_code = '431010-Ubank Limited';
UPDATE t_pocket_bank_support SET bank_id =2500012 WHERE bank_code = '450105-Mercantile Bank';
UPDATE t_pocket_bank_support SET bank_id =2500013 WHERE bank_code = '462005-Bidvest Bank';
UPDATE t_pocket_bank_support SET bank_id =2500014 WHERE bank_code = '470010-Capitec';
UPDATE t_pocket_bank_support SET bank_id =2500015 WHERE bank_code = '580105-Investec';
UPDATE t_pocket_bank_support SET bank_id =2500016 WHERE bank_code = '587000-HSBC Bank';
UPDATE t_pocket_bank_support SET bank_id =2500017 WHERE bank_code = '632005-ABSA';
UPDATE t_pocket_bank_support SET bank_id =2500018 WHERE bank_code = '678910-TymeBank';
UPDATE t_pocket_bank_support SET bank_id =2500019 WHERE bank_code = '679000-Discovery Bank';
UPDATE t_pocket_bank_support SET bank_id =2500020 WHERE bank_code = '683000-Sasfin';
UPDATE t_pocket_bank_support SET bank_id =2500021 WHERE bank_code = '686000-Bank Of China';
UPDATE t_pocket_bank_support SET bank_id =2500022 WHERE bank_code = '730020-Standard Chartered Bank';
UPDATE t_pocket_bank_support SET bank_id =2500023 WHERE bank_code = '760005-Permanent Bank';
